import json
import feedparser

def get_recent_episodes(podcast_url, num_episodes):
    feed = feedparser.parse(podcast_url)
    
    return feed

def lambda_handler(event, context):
    podcast_url = "https://itunes.apple.com/lookup?id=1705378048&country=US&media=podcast&entity=podcastEpisode&limit=5"
    recent_episodes = get_recent_episodes(podcast_url)

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': True,
        },
        'body': json.dumps(recent_episodes)
    }