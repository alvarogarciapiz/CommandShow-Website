import requests
import json

def lambda_handler(event, context):
    url = 'https://itunes.apple.com/lookup?id=1705378048&country=US&media=podcast&entity=podcastEpisode&limit=5'
    response = requests.get(url)
    data = json.loads(response.content)

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true',
        },
        'body': json.dumps(data, indent=4)
    }