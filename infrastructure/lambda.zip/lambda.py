import json
import feedparser

def get_recent_episodes(podcast_url, num_episodes):
    feed = feedparser.parse(podcast_url)
    episodes = []
    
    for entry in feed.entries[:num_episodes]:
        episode = {
            'title': entry.title,
            'published': entry.published,
            'link': entry.link
        }
        episodes.append(episode)
    
    return episodes

def lambda_handler(event, context):
    podcast_url = "https://anchor.fm/s/e81d467c/podcast/rss"
    num_episodes = 5
    recent_episodes = get_recent_episodes(podcast_url, num_episodes)

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': 'https://command-show-website.s3.eu-south-2.amazonaws.com',
            'Access-Control-Allow-Credentials': True,
        },
        'body': json.dumps(recent_episodes)
    }