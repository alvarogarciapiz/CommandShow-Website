import requests

def lambda_handler(event, context):
    url = 'https://itunes.apple.com/lookup?id=1705378048&country=US&media=podcast&entity=podcastEpisode&limit=5'
    response = requests.get(url)
    return response.content


import requests
import json

def lambda_handler(event, context):
    url = 'https://itunes.apple.com/lookup?id=1705378048&country=US&media=podcast&entity=podcastEpisode&limit=5'
    response = requests.get(url)
    data = response.content

    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': True,
        },
        'body': json.dumps(data.decode("utf-8"))
    }